</main>

<footer class="main-footer">
    <div class="container">
        <p>&copy; <?php echo date("Y"); ?> Perpustakaan Umum. Semua Hak Cipta Dilindungi.</p>
    </div>
</footer>

</body>
</html>